package com.mycompany.bookinghistory;

import java.util.*;

public class BookingHistory {

    public static void main(String[] args) {
        List<Booking> bookings = new ArrayList<>();
        
        FlightBooking fb = new FlightBooking("FL001", "John Doe", "13-10-2026", "ABC123", "Dhaka");
        bookings.add(fb);
        System.out.println();
        
        HotelBooking hb = new HotelBooking("HB001", "CLara Croft", "22-05-2026", 5, "Hilton");
        bookings.add(hb);
        System.out.println();
        
        EventBooking eb = new EventBooking("EB001", "Alice Brown", "05-11-2026", "Music Concert", 100);
        bookings.add(eb);
        System.out.println();
        
        for(Booking booking : bookings){
            booking.confirmBooking();
            booking.cancelBooking();
        }
    }
}
