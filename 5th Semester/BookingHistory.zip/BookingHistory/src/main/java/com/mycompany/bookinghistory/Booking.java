package com.mycompany.bookinghistory;

public abstract class Booking {
    private String bookingID;
    private String customerName;
    private String bookingDate;

    public Booking(String bookingID, String customerName, String bookingDate) {
        this.bookingID = bookingID;
        this.customerName = customerName;
        this.bookingDate = bookingDate;
    }

    public String getBookingID() {
        return bookingID;
    }

    public String getCustomerName() {
        return customerName;
    }

    public String getBookingDate() {
        return bookingDate;
    }
    
    public abstract void confirmBooking();
    public abstract void cancelBooking();
}
