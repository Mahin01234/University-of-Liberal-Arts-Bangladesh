package com.mycompany.bookinghistory;

public class EventBooking extends Booking{
    private String eventName;
    private int numOfGuests;

    public EventBooking(String bookingID, String customerName, String bookingDate, String eventName, int numOfGuests) {
        super(bookingID, customerName, bookingDate);
        this.eventName = eventName;
        this.numOfGuests = numOfGuests;
    }

    public String getEventName() {
        return eventName;
    }

    public int getNumOfGuests() {
        return numOfGuests;
    }

    @Override
    public void confirmBooking() {
        System.out.println("Event booking confrimed for " + eventName + " for " + numOfGuests);
    }

    @Override
    public void cancelBooking() {
        System.out.println("Event booking confrimed for " + eventName + " for " + numOfGuests);
    }
    
    
}
