package com.mycompany.bookinghistory;

class FlightBooking extends Booking{
    private String flightNumber;
    private String destination;

    public FlightBooking(String flightNumber, String destination, String bookingID, String customerName, String bookingDate) {
        super(bookingID, customerName, bookingDate);
        this.flightNumber = flightNumber;
        this.destination = destination;
    }

    public String getFlightNumber() {
        return flightNumber;
    }

    public String getDestination() {
        return destination;
    }

    @Override
    public void confirmBooking() {
        System.out.println("Flight booking confrimed for flight number " + flightNumber + " to " + destination);
    }

    @Override
    public void cancelBooking() {
        System.out.println("Flight booking cancel for flight number " + flightNumber + " to " + destination);
    }
}
