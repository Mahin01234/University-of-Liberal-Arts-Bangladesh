package com.mycompany.bookinghistory;

public class HotelBooking extends Booking{
    private String hotelName;
    private int numOfRooms;

    public HotelBooking(String bookingID, String customerName, String bookingDate, int numOfRooms, String hotelName) {
        super(bookingID, customerName, bookingDate);
        this.hotelName = hotelName;
        this.numOfRooms = numOfRooms;
    }

    public String getHotelName() {
        return hotelName;
    }

    public int getNumOfRooms() {
        return numOfRooms;
    }

    @Override
    public void confirmBooking() {
        System.out.println(numOfRooms + " rooms booked at " + hotelName);
    }

    @Override
    public void cancelBooking() {
        System.out.println("Hotel booking canceled at " + hotelName);
    }
    
    
}
