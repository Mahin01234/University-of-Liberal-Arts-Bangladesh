/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.question_2;

/**
 *
 * @author DELL
 */
public class Manager extends Employee 

{
    
    
    private String department ;  
    private int performanceBonus ; 

    
    
    
    
    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public int getPerformanceBonus() {
        return performanceBonus;
    }

    public void setPerformanceBonus(int performanceBonus) {
        this.performanceBonus = performanceBonus;
    }
    
    
    
    
   public Manager ( String Name , int Id , int Salary , String department , int performanceBonus ) 
   {
       super (Name , Id , Salary ) ; 
       
       
       this.department = department ; 
       
       this.performanceBonus = performanceBonus  ; 
       
       
       
   } 
   
   
   
   
   
   
   
   public int calculateTotalSalary() 
   {
       
       return getSalary() + performanceBonus ; 
       
   }
   
   
   
   
   
   @Override 
   
   public void display ()
   {
       
       super.display() ; 
       
       
       
       
       System.out.println ("Department : " + department) ;
       
       System.out.println ("Performance Bonus : " + performanceBonus) ;
        
       System.out.println ("Total Salary : " + calculateTotalSalary() ) ;
    
       
       
       
   }
}
