package com.mycompany.question_2;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        try (Scanner input = new Scanner(System.in)) {
            ArrayList<Employee> list = new ArrayList<>();
            
            // Input for 2 Managers
            for (int i = 1; i <= 2; i++) {
                
                System.out.println("Enter Manager " + i);
                
                System.out.print("Name : ");
                String Name = input.next();
                
                System.out.print("ID : ");
                int Id = input.nextInt();
                
                System.out.print("Salary : ");
                int Salary = input.nextInt();
                
                System.out.print("Department : ");
                String department = input.next();
                
                System.out.print("Performance Bonus : ");
                int performanceBonus = input.nextInt();
                
                Manager M = new Manager(Name, Id, Salary, department, performanceBonus);
                
                list.add(M);
                
                System.out.println();
            }
            
            // Input for 2 Engineers
            for (int i = 1; i <= 2; i++) {
                
                System.out.println("Enter Engineer " + i);
                
                System.out.print("Name : ");
                String Name = input.next();
                
                System.out.print("ID : ");
                int Id = input.nextInt();
                
                System.out.print("Salary : ");
                int Salary = input.nextInt();
                
                System.out.print("Specialization : ");
                String specialization = input.next();
                
                System.out.print("Project Bonus : ");
                int projectBonus = input.nextInt();
                
                Engineer E = new Engineer(Name, Id, Salary, specialization, projectBonus);
                
                list.add(E);
                
                System.out.println();
            }
            
            // Display all employee information
                      
            for (Employee emp : list) {
                
                switch (emp) {
                    case Manager M -> M.display();
                    case Engineer E -> E.display();
                    default -> {
                    }
                }
                
                System.out.println("-------------------------------");
            }
        }
    }
}