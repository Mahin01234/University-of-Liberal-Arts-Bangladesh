/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.question_2;

/**
 *
 * @author DELL
 */
public class Question_2 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
