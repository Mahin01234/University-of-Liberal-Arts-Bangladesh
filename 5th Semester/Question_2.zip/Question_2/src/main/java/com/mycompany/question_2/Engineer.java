/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.question_2;

/**
 *
 * @author DELL
 */
public class Engineer extends Employee 

{
    
    
    private String specialization ; 
    private int projectBonus ; 

    
    
    
    
    
    
    
    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public int getProjectBonus() {
        return projectBonus;
    }

    public void setProjectBonus(int projectBonus) {
        this.projectBonus = projectBonus;
    }
    
    
    
    
    
    
    
    
    public Engineer ( String Name , int Id , int Salary  , String specialization , int projectBonus ) 
    {
        
        
        super (Name , Id , Salary ) ; 
        
        
        
        this.specialization = specialization ; 
        
        this.projectBonus =  projectBonus ; 
        
        
        
        
    }
    
    
    
    
    
    
    
    
    
    public int calculateTotalSalary() 
    {
        
        
        return getSalary() + projectBonus  ;
        
        
        
    }
    
    
    
    
    @Override 
    
    public void display () 
    {
        
        super.display() ;
        
        
        System.out.println ("Specialization : " + specialization)  ;
        
        System.out.println ("Project Bonus : " + projectBonus) ; 
        
      
        System.out.println ("Total Salary : " + calculateTotalSalary()  )  ;
        
    }
}
