/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.question_2;

/**
 *
 * @author DELL
 */
public class Employee 


{
    
    
    private String Name ; 
    private int Id , Salary ; 

    
    
    
    
    
    
    
    
    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public int getId() {
        return Id;
    }

    public void setId(int Id) {
        this.Id = Id;
    }

    public int getSalary() {
        return Salary;
    }

    public void setSalary(int Salary) {
        this.Salary = Salary;
    }
    
    
    
    
    
    public Employee ( String Name , int Id , int Salary ) 
    {
        
        this.Name = Name ; 
        this.Id = Id ; 
        this.Salary = Salary ; 
        
        
    }
    
    
    
    
    
    
    
    
    
    
    public void display () 
    {
        
        System.out.println ("Employee name is : " + Name ) ;  
        
        System.out.println ("Employee id is : " + Id ) ; 
        
        System.out.println ("Employee salary is : " + Salary ) ; 
        
        
    }
    
    
    
    
    
}
