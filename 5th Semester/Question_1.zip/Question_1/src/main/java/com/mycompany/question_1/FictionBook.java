/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.question_1;

/**
 *
 * @author DELL
 */
public class FictionBook extends PrintedBook

        
        
{
    
    private String genre ; 
    private int recommendedAge ; 

    
    
    
    
    
    
    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public int getRecommendedAge() {
        return recommendedAge;
    }

    public void setRecommendedAge(int recommendedAge) {
        this.recommendedAge = recommendedAge;
    }

    

    
    
    
    
    
    
    public FictionBook(String title , String author , int price , String publisher, int numberOfPages , String genre , int recommendedAge ) 
    {


        super(title , author , price , publisher , numberOfPages ) ;

        
        
        this.genre = genre ;
        this.recommendedAge = recommendedAge ;
        
        
        
    }
    
    
    

    
    
    
    
    @Override
    
    
    public void display () 
    {

        super.display () ; 
        

        System.out.println("Genre : " + genre) ;
        System.out.println("Recommended Age : " + recommendedAge) ; 
        
        
        
        
    }
    
    
    
    
    
    
    
    
    public void recommendBook() 
    {
        if (getGenre().equalsIgnoreCase ("Fantasy") ) 
        {
            System.out.println("Great for fantasy.") ;
        } 
        
        
        else if  (getGenre().equalsIgnoreCase("Romance") ) 
        {
            System.out.println("Great for lovers.");
        } 
        
        
        
        else 
        {
            System.out.println("Recommended for history.");
        }
        
        
        
        
        
        
    }
    
}
    
    
    
    
    
    
    
    
    
    
    

