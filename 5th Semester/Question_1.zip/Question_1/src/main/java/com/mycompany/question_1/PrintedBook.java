/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.question_1;

/**
 *
 * @author DELL
 */
public class PrintedBook extends Book 
{
    
    private String publisher ; 
    
    private int numberOfPages ; 

    
    
    
    
    
    
    
    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public int getNumberOfPages() {
        return numberOfPages;
    }

    public void setNumberOfPages(int numberOfPages) {
        this.numberOfPages = numberOfPages;
    }
    
    
    
    
    
    
    
    
    public PrintedBook (String title , String author , int price , String publisher , int numberOfPages ) 
    {
        
        super (title, author, price);
        
        
        this.publisher = publisher ; 
        this.numberOfPages = numberOfPages ; 
        
        
        
    }
    
    
    
    
    
    
    @Override 
    
    public void display ()
    {
        
        
        super.display () ;  
        
        
        
        System.out.println ("The publisher name is : " + publisher ) ;
        
        System.out.println ("The book is number of pages : " + numberOfPages ) ; 
        
        
    }
}
