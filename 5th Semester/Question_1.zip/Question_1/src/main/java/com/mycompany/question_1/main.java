/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.question_1;

/**
 *
 * @author DELL
 */
import java.util.ArrayList;
import java.util.Scanner;

public class main 


{
    public static void main(String[] args) 
    
    
    {

        try (Scanner input = new Scanner(System.in)) {
            ArrayList<PrintedBook> books = new ArrayList<>();
            
            // Create 2 FictionBook objects
            for (int i = 1; i <= 2; i++) {
                
                System.out.println("\nEnter details for Fiction Book " + i);
                
                System.out.print("Title: ");
                String title = input.nextLine();
                
                System.out.print("Author: ");
                String author = input.nextLine();
                
                System.out.print("Price: ");
                int price = input.nextInt ();
                input.nextLine();
                
                System.out.print("Publisher: ");
                String publisher = input.nextLine();
                
                System.out.print("Number of Pages: ");
                int numberOfPages = input.nextInt();
                input.nextLine();
                
                System.out.print("Genre: ");
                String genre = input.nextLine();
                
                System.out.print("Recommended Age: ");
                int recommendedAge = input.nextInt();
                input.nextLine();
                
                FictionBook fictionBook = new FictionBook(title,author,price,publisher,numberOfPages,genre,recommendedAge ) ;
                
                books.add(fictionBook);
            }
            
            // Create 2 NonFictionBook objects
            for (int i = 1; i <= 2; i++)
                
                
                
            {
                
                System.out.println("\nEnter details for Non-Fiction Book " + i);
                
                System.out.print("Title: ");
                String title = input.nextLine();
                
                System.out.print("Author: ");
                String author = input.nextLine();
                
                System.out.print("Price: ");
                int price = input.nextInt();
                input.nextLine();
                
                System.out.print("Publisher: ");
                String publisher = input.nextLine();
                
                System.out.print("Number of Pages: ");
                int numberOfPages = input.nextInt();
                input.nextLine();
                
                System.out.print("Subject: ");
                String subject = input.nextLine();
                
                System.out.print("Edition: ");
                String edting = input.nextLine();
                
                NonFictionBook nonFictionBook = new NonFictionBook (title,author,price,publisher,numberOfPages,subject,edting ) ;
                
                books.add(nonFictionBook);
            }
            
            
            
            
            for (PrintedBook book : books)
                
                
            {
                
                System.out.println("\n------------------------------");
                
                book.display();
                
                System.out.println("------------------------------");
                
                
                
                
                switch (book) 
                {
                    case FictionBook fictionBook -> fictionBook.recommendBook();
                    case NonFictionBook nonFictionBook -> nonFictionBook.showReferenceInfo();
                    default -> {
                    }
                    
                    
                    
                }
            }
        }
    }
}
