/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.question_1;

/**
 *
 * @author DELL
 */
public class NonFictionBook extends PrintedBook 
        
{
    
    
    private String subject ; 
    private String edting ; 

    
    
    
    
    
    
    
    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getEdting() {
        return edting;
    }

    public void setEdting(String edting) {
        this.edting = edting;
    }
    
    
    
    
    
    
    
    public NonFictionBook(String title, String author, int price, String publisher, int numberOfPages, String subject, String edting) {

      
        super(title, author, price, publisher, numberOfPages);

        this.subject = subject;
        this.edting = edting ; 
        
    }
    
    
    
   
    
    
    @Override 
    
    public void display () 
    {
        

        super.display();

        System.out.println("Subject : " + subject);
        System.out.println("Edition : " + edting ); 
        
        
        
        
    }
    
    
    
    
    
    
    
    public void showReferenceInfo() 
    {

        System.out.println("Reference Subject : " + subject ) ; 
        System.out.println("Edition : " + edting)  ; 
        
        
        
    }
    
}
