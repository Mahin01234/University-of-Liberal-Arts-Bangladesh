/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.question_1;

/**
 *
 * @author DELL
 */
public class Book 
{
    
    protected String title , author ; 
    protected int price ; 

    
    
    
    
    
    
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
    
    
    
    
    
    
    
    
    public Book (String title , String author , int price ) 
    {
        
        this.title = title ; 
        this.author = author ; 
        this.price  = price ; 
        
        
    }
    
    
    
    
    
    public void display () 
    {
     
        System.out.println ("The title name is : " + title ) ; 
        System.out.println ("The author name is : " + author )  ; 
        System.out.println ("Price is : " + price ) ; 
        
        
        
    }
    
    
    
    
}
